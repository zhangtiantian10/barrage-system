#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtWebChannel/QtWebChannel>
#include <QtWebEngineWidgets/QtWebEngineWidgets>

namespace Ui {
class MainWindow;
}

class MainWindow : public QWebEngineView
{
  Q_OBJECT

public:
  explicit MainWindow(QWidget *parent = 0);
  ~MainWindow();

private:
  int windowHeight;
  int windowWidth;

  void setupWeb();
  void alignScreen();
  void setupWindowStyle();
};

#endif // MAINWINDOW_H
