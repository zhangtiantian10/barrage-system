#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
  QWebEngineView(parent)
{
  windowHeight = 250;
  windowWidth = 250;
  setupWeb();
  setupWindowStyle();
  alignScreen();
  setWindowOpacity(0.7);
  setAttribute(Qt::WA_TranslucentBackground, true);
}

MainWindow::~MainWindow()
{
}

void MainWindow::setupWeb()
{
//  setHtml("<body style=\"background: red;\"><h1>Hello</h1> <h2>html</h2></body>");
  setUrl(QUrl("http://localhost:3007/barrage"));
}

void MainWindow::alignScreen()
{
  QDesktopWidget *desktop = QApplication::desktop();
  QRect screenRect = desktop->screenGeometry();
  int centerOfHeight = screenRect.height() / 2 + windowHeight / 2;
  // 窗口大小
  resize(windowWidth, windowHeight);
  // 窗口位置
  move(0, centerOfHeight);
}

void MainWindow::setupWindowStyle()
{
  // 窗口置顶 | 少边框
  setWindowFlags(Qt::WindowStaysOnTopHint | Qt::FramelessWindowHint);
}
